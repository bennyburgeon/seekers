
<footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                
              </div>
            </footer>
<div class="content-backdrop fade"></div>
               </div>
            </div>
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->
  </body>
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="<?php echo base_url('candidate/assets/vendor/libs/jquery/jquery.js');?>"></script>
    <script src="<?php echo base_url('candidate/assets/vendor/libs/popper/popper.js');?>"></script>
    <script src="<?php echo base_url('candidate/assets/vendor/js/bootstrap.js');?>"></script>
    <script src="<?php echo base_url('candidate/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js');?>"></script>
    <script src="<?php echo base_url('candidate/assets/vendor/js/menu.js');?>"></script>
    <script src="<?php echo base_url('candidate/assets/js/main.js');?>"></script>
    <script src="<?php echo base_url('candidate/assets/js/notify.js');?>"></script>
    <script src="<?php echo base_url('candidate/assets/js/notify.min.js');?>"></script>
    <script src="<?php echo base_url('candidate/assets/js/dashboards-analytics.js');?>"></script>
    <script src="<?php echo base_url('candidate/assets/js/pages-account-settings-account.js');?>"></script>
<script type="text/javascript">

$(document).ready(function(){
   $('.resume_headline').click(function() {
      $('#resume_headline').focus();
   });
   $('.personal_details').click(function() {
      $('#personal_details').focus();
   });
   $('.professional_summery').click(function() {
      $('#professional_summery').focus();
   });
   $('.desired_jobs').click(function() {
      $('#desired_jobs').focus();
   });
   $('.employment').click(function() {
      $('#employment').focus();
   });
   $('.skills').click(function() {
      $('#skills').focus();
   });
   $('.other_details').click(function() {
      $('#other_details').focus();
   });
   $('.photo_cv').click(function() {
      $('#photo_cv').focus();
   });
   

});
</script>
</html>